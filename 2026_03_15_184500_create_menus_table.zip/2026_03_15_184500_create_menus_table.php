<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('menus', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // Contoh: Soto Ayam Spesial
            $table->text('description')->nullable(); // Contoh: Soto ayam kampung kuah bening...
            $table->decimal('price', 10, 2)->nullable(); // Contoh: 25000
            $table->string('image')->nullable(); // Path foto menu
            $table->boolean('is_active')->default(true); // Status aktif/non-aktif
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('menus');
    }
};