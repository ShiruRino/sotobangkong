<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('outlets', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // Contoh: Soto Bangkong - Pakubuwono
            $table->string('region'); // Contoh: jaksel, jakpus (untuk filter frontend)
            $table->text('address'); // Alamat lengkap
            $table->string('open_hours'); // Contoh: 07.30 - 21.00 WIB
            $table->string('map_link')->nullable(); // Link Google Maps
            $table->string('image')->nullable(); // Foto outlet
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('outlets');
    }
};