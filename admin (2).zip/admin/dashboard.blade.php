@extends('adminlte::page')

@section('title', 'Dashboard - CMS Soto Bangkong')

@section('content_header')
    <h1>Dashboard Admin</h1>
@stop

@section('content')
    <div class="row">
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
                <div class="inner">
                    <h3>15</h3>
                    <p>Total Menu Makanan</p>
                </div>
                <div class="icon">
                    <i class="fas fa-utensils"></i>
                </div>
                <a href="{{ url('admin/menus') }}" class="small-box-footer">Kelola Menu <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
                <div class="inner">
                    <h3>4</h3>
                    <p>Cabang / Outlet</p>
                </div>
                <div class="icon">
                    <i class="fas fa-store"></i>
                </div>
                <a href="{{ url('admin/outlets') }}" class="small-box-footer">Kelola Outlet <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
                <div class="inner">
                    <h3>24</h3>
                    <p>Foto Galeri</p>
                </div>
                <div class="icon">
                    <i class="fas fa-images"></i>
                </div>
                <a href="{{ url('admin/gallery') }}" class="small-box-footer">Kelola Galeri <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
                <div class="inner">
                    <h3>5</h3>
                    <p>Pesan Kontak Baru</p>
                </div>
                <div class="icon">
                    <i class="fas fa-envelope"></i>
                </div>
                <a href="#" class="small-box-footer">Cek Pesan <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <!-- ./col -->
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Selamat Datang di CMS Soto Bangkong</h3>
        </div>
        <div class="card-body">
            <p>Gunakan menu di sebelah kiri untuk mengelola konten website publik Anda. Semua perubahan teks dan gambar akan langsung diperbarui di website utama.</p>
        </div>
    </div>
@stop

@section('css')
    <!-- Tambahkan custom CSS khusus admin di sini jika diperlukan -->
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <!-- Tambahkan custom JS khusus admin di sini jika diperlukan -->
    <script>
        console.log('Dashboard AdminLTE dimuat!');
    </script>
@stop