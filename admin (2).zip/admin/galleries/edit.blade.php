@extends('adminlte::page')

@section('title', 'Edit Foto Galeri')

@section('content_header')
    <h1>Edit Foto: {{ $gallery->title }}</h1>
@stop

@section('content')
    <div class="card card-warning">
        <form action="{{ route('gallery.update', $gallery->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="card-body">
                <div class="form-group">
                    <label for="title">Judul Foto / Keterangan <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control @error('title') is-invalid @enderror" id="title" value="{{ old('title', $gallery->title) }}" required>
                    @error('title') <span class="text-danger">{{ $message }}</span> @enderror
                </div>

                <div class="form-group">
                    <label for="image">File Foto (Biarkan kosong jika tidak ingin mengubah)</label>
                    @if($gallery->image)
                        <div class="mb-2">
                            <img src="{{ asset('storage/' . $gallery->image) }}" alt="Current Image" class="img-thumbnail" width="200">
                        </div>
                    @endif
                    <div class="custom-file">
                        <input type="file" name="image" class="custom-file-input @error('image') is-invalid @enderror" id="image" accept="image/*">
                        <label class="custom-file-label" for="image">Pilih file gambar baru (Max 2MB)</label>
                    </div>
                    @error('image') <span class="text-danger">{{ $message }}</span> @enderror
                </div>

                <div class="form-group">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" name="is_active" class="custom-control-input" id="is_active" {{ $gallery->is_active ? 'checked' : '' }}>
                        <label class="custom-control-label" for="is_active">Tampilkan di Halaman Galeri</label>
                    </div>
                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-warning"><i class="fas fa-save"></i> Update Foto</button>
                <a href="{{ route('gallery.index') }}" class="btn btn-default float-right">Batal</a>
            </div>
        </form>
    </div>
@stop

@section('js')
<script>
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });
</script>
@stop