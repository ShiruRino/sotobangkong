@extends('adminlte::page')

@section('title', 'Inbox Pesan')

@section('content_header')
    <h1>Inbox Pesan Masuk</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">
            @if(session('success'))
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    {{ session('success') }}
                </div>
            @endif

            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th width="5%">Status</th>
                        <th>Pengirim</th>
                        <th>Subjek</th>
                        <th>Tanggal</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($messages as $msg)
                        <tr style="{{ !$msg->is_read ? 'font-weight: bold; background-color: #f4f6f9;' : '' }}">
                            <td>
                                @if(!$msg->is_read)
                                    <span class="badge badge-primary">Baru</span>
                                @else
                                    <span class="badge badge-secondary">Dibaca</span>
                                @endif
                            </td>
                            <td>
                                {{ $msg->name }}<br>
                                <small class="text-muted">{{ $msg->email }}</small>
                            </td>
                            <td>{{ $msg->subject }}</td>
                            <td>{{ $msg->created_at->format('d M Y, H:i') }}</td>
                            <td>
                                <a href="{{ route('messages.show', $msg->id) }}" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> Baca
                                </a>
                                <form action="{{ route('messages.destroy', $msg->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Hapus pesan ini?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center">Tidak ada pesan masuk.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@stop