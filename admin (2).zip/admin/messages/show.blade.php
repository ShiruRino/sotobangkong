@extends('adminlte::page')

@section('title', 'Detail Pesan')

@section('content_header')
    <h1>Detail Pesan</h1>
@stop

@section('content')
    <div class="row">
        <div class="col-md-3">
            <a href="{{ route('messages.index') }}" class="btn btn-primary btn-block mb-3">Kembali ke Inbox</a>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Info Pengirim</h3>
                </div>
                <div class="card-body p-0">
                    <ul class="nav nav-pills flex-column">
                        <li class="nav-item">
                            <span class="nav-link">
                                <i class="fas fa-user"></i> {{ $message->name }}
                            </span>
                        </li>
                        <li class="nav-item">
                            <span class="nav-link">
                                <i class="fas fa-envelope"></i> {{ $message->email }}
                            </span>
                        </li>
                        <li class="nav-item">
                            <span class="nav-link">
                                <i class="fas fa-phone"></i> {{ $message->phone }}
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-9">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">Baca Pesan</h3>
                    <div class="card-tools">
                        <span class="mailbox-read-time float-right">{{ $message->created_at->format('d M Y H:i') }}</span>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="mailbox-read-info">
                        <h5>Subjek: {{ $message->subject }}</h5>
                    </div>
                    <div class="mailbox-read-message p-4">
                        <p>{{ $message->message }}</p>
                    </div>
                </div>
                <div class="card-footer">
                    <form action="{{ route('messages.destroy', $message->id) }}" method="POST" onsubmit="return confirm('Hapus pesan ini?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-default"><i class="far fa-trash-alt"></i> Hapus</button>
                        <a href="mailto:{{ $message->email }}" class="btn btn-default"><i class="fas fa-reply"></i> Balas via Email</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop