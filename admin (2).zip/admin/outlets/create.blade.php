@extends('adminlte::page')

@section('title', 'Tambah Outlet')

@section('content_header')
    <h1>Tambah Cabang Baru</h1>
@stop

@section('content')
    <div class="card card-primary">
        <form action="{{ route('outlets.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">Nama Cabang <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" id="name" placeholder="Contoh: Soto Bangkong - Pakubuwono" value="{{ old('name') }}" required>
                            @error('name') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="region">Kategori Wilayah <span class="text-danger">*</span></label>
                            <select name="region" class="form-control @error('region') is-invalid @enderror" id="region" required>
                                <option value="">-- Pilih Wilayah --</option>
                                <option value="jaksel" {{ old('region') == 'jaksel' ? 'selected' : '' }}>Jakarta Selatan (jaksel)</option>
                                <option value="jakpus" {{ old('region') == 'jakpus' ? 'selected' : '' }}>Jakarta Pusat (jakpus)</option>
                                <option value="tangsel" {{ old('region') == 'tangsel' ? 'selected' : '' }}>Tangerang Selatan (tangsel)</option>
                                <!-- Tambahkan opsi lain jika perlu -->
                            </select>
                            <small class="text-muted">Digunakan untuk filter di halaman depan.</small>
                            @error('region') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="address">Alamat Lengkap <span class="text-danger">*</span></label>
                    <textarea name="address" class="form-control @error('address') is-invalid @enderror" id="address" rows="3" placeholder="Contoh: Jl. Pakubuwono VI No.39, RT.11/RW.2..." required>{{ old('address') }}</textarea>
                    @error('address') <span class="text-danger">{{ $message }}</span> @enderror
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="open_hours">Jam Operasional <span class="text-danger">*</span></label>
                            <input type="text" name="open_hours" class="form-control @error('open_hours') is-invalid @enderror" id="open_hours" placeholder="Contoh: Buka: 07.30 - 21.00 WIB" value="{{ old('open_hours') }}" required>
                            @error('open_hours') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="map_link">Link Google Maps (Opsional)</label>
                            <input type="url" name="map_link" class="form-control @error('map_link') is-invalid @enderror" id="map_link" placeholder="Contoh: https://goo.gl/maps/..." value="{{ old('map_link') }}">
                            @error('map_link') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="image">Foto Outlet</label>
                    <div class="custom-file">
                        <input type="file" name="image" class="custom-file-input @error('image') is-invalid @enderror" id="image" accept="image/*">
                        <label class="custom-file-label" for="image">Pilih file gambar (Max 2MB)</label>
                    </div>
                    @error('image') <span class="text-danger">{{ $message }}</span> @enderror
                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Outlet</button>
                <a href="{{ route('outlets.index') }}" class="btn btn-default float-right">Batal</a>
            </div>
        </form>
    </div>
@stop

@section('js')
<script>
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });
</script>
@stop