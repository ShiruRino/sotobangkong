@extends('adminlte::page')

@section('title', 'Daftar Outlet')

@section('content_header')
    <h1>Kelola Daftar Outlet / Cabang</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <a href="{{ route('outlets.create') }}" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Cabang Baru</a>
        </div>
        <div class="card-body">
            @if(session('success'))
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    {{ session('success') }}
                </div>
            @endif

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th width="15%">Foto Cabang</th>
                        <th>Info Cabang</th>
                        <th>Wilayah (Filter)</th>
                        <th>Jam Buka</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($outlets as $index => $item)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>
                                @if($item->image)
                                    <img src="{{ asset('storage/' . $item->image) }}" alt="{{ $item->name }}" class="img-thumbnail" width="120">
                                @else
                                    <span class="text-muted">Tidak ada foto</span>
                                @endif
                            </td>
                            <td>
                                <strong>{{ $item->name }}</strong><br>
                                <small><i class="fas fa-map-marker-alt text-danger"></i> {{ Str::limit($item->address, 50) }}</small>
                            </td>
                            <td>
                                <span class="badge badge-info">{{ strtoupper($item->region) }}</span>
                            </td>
                            <td>{{ $item->open_hours }}</td>
                            <td>
                                <a href="{{ route('outlets.edit', $item->id) }}" class="btn btn-sm btn-warning mb-1"><i class="fas fa-edit"></i> Edit</a>
                                <form action="{{ route('outlets.destroy', $item->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus cabang ini?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger mb-1"><i class="fas fa-trash"></i> Hapus</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center">Belum ada data outlet/cabang.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@stop