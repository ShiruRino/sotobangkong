@extends('adminlte::page')

@section('title', 'Pengaturan Website')

@section('content_header')
    <h1>Pengaturan Umum Website</h1>
@stop

@section('content')
    <div class="card card-primary card-tabs">
        <div class="card-header p-0 pt-1">
            <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="kontak-tab" data-toggle="pill" href="#kontak" role="tab">Kontak & Sosmed</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="about-tab" data-toggle="pill" href="#about" role="tab">Halaman About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="facts-tab" data-toggle="pill" href="#facts" role="tab">Statistik (Fun Facts)</a>
                </li>
            </ul>
        </div>
        <form action="{{ route('settings.update') }}" method="POST">
            @csrf
            <div class="card-body">
                <div class="tab-content" id="custom-tabs-one-tabContent">
                    @if(session('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                    @endif

                    <!-- Tab Kontak -->
                    <div class="tab-pane fade show active" id="kontak" role="tabpanel">
                        <div class="row">
                            <div class="col-md-6">
                                <h4><i class="fas fa-info-circle"></i> Informasi Kontak</h4>
                                <hr>
                                <div class="form-group">
                                    <label>Nomor Telepon Kantor</label>
                                    <input type="text" name="phone" class="form-control" value="{{ $settings['phone'] ?? '' }}">
                                </div>
                                <div class="form-group">
                                    <label>WhatsApp (Untuk Order)</label>
                                    <input type="text" name="whatsapp" class="form-control" value="{{ $settings['whatsapp'] ?? '' }}">
                                </div>
                                <div class="form-group">
                                    <label>Email Resmi</label>
                                    <input type="email" name="email" class="form-control" value="{{ $settings['email'] ?? '' }}">
                                </div>
                                <div class="form-group">
                                    <label>Alamat Pusat</label>
                                    <textarea name="address" class="form-control" rows="3">{{ $settings['address'] ?? '' }}</textarea>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <h4><i class="fab fa-share-alt"></i> Media Sosial</h4>
                                <hr>
                                <div class="form-group">
                                    <label>Link Instagram</label>
                                    <input type="url" name="instagram" class="form-control" value="{{ $settings['instagram'] ?? '' }}" placeholder="https://instagram.com/...">
                                </div>
                                <div class="form-group">
                                    <label>Link Facebook</label>
                                    <input type="url" name="facebook" class="form-control" value="{{ $settings['facebook'] ?? '' }}">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <h4><i class="fas fa-clock"></i> Jam Operasional Global</h4>
                            <hr>
                            <div class="form-group">
                                <label>Teks Jam Operasional (Footer)</label>
                                <input type="text" name="opening_hours" class="form-control" value="{{ $settings['opening_hours'] ?? '' }}" placeholder="Senin - Minggu: 07:30 - 21:00">
                            </div>
                        </div>
                    </div>

                    <!-- Tab About Page -->
                    <div class="tab-pane fade" id="about" role="tabpanel">
                        <div class="form-group">
                            <label>Sub-Judul Halaman About</label>
                            <input type="text" name="about_subtitle" class="form-control" value="{{ $settings['about_subtitle'] ?? 'Kisah Sejarah Soto Bangkong' }}">
                        </div>
                        <div class="form-group">
                            <label>Judul Sejarah</label>
                            <input type="text" name="about_history_title" class="form-control" value="{{ $settings['about_history_title'] ?? 'SEJARAH SOTO BANGKONG' }}">
                        </div>
                        <div class="form-group">
                            <label>Konten Sejarah (Gunakan enter untuk baris baru)</label>
                            <textarea name="about_history_content" class="form-control" rows="5">{{ $settings['about_history_content'] ?? '' }}</textarea>
                        </div>
                        <hr>
                        <div class="form-group">
                            <label>Konten Filosofi Rasa</label>
                            <textarea name="about_philosophy_content" class="form-control" rows="5">{{ $settings['about_philosophy_content'] ?? '' }}</textarea>
                        </div>
                    </div>

                    <!-- Tab Fun Facts -->
                    <div class="tab-pane fade" id="facts" role="tabpanel">
                        <div class="row">
                            <div class="col-md-3">
                                <label>Tahun Berdiri</label>
                                <input type="number" name="fact_years" class="form-control" value="{{ $settings['fact_years'] ?? '0' }}">
                            </div>
                            <div class="col-md-3">
                                <label>Porsi Terjual / Hari</label>
                                <input type="number" name="fact_portions" class="form-control" value="{{ $settings['fact_portions'] ?? '0' }}">
                            </div>
                            <div class="col-md-3">
                                <label>Jumlah Cabang</label>
                                <input type="number" name="fact_outlets" class="form-control" value="{{ $settings['fact_outlets'] ?? '0' }}">
                            </div>
                            <div class="col-md-3">
                                <label>% Pelanggan Puas</label>
                                <input type="number" name="fact_satisfied" class="form-control" value="{{ $settings['fact_satisfied'] ?? '0' }}">
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Simpan Semua Perubahan</button>
            </div>
        </form>
    </div>
@stop