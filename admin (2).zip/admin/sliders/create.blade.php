@extends('adminlte::page')

@section('title', 'Tambah Banner')

@section('content_header')
    <h1>Tambah Banner Depan</h1>
@stop

@section('content')
    <div class="card">
        <form action="{{ route('sliders.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="card-body">
                <div class="form-group">
                    <label>Judul Oranye (Opsional)</label>
                    <input type="text" name="title_orange" class="form-control" placeholder="Contoh: SOTOBANGKONG">
                </div>
                <div class="form-group">
                    <label>Judul Putih (Opsional)</label>
                    <input type="text" name="title_white" class="form-control" placeholder="Contoh: JAKARTA">
                </div>
                <div class="form-group">
                    <label>Deskripsi Singkat</label>
                    <textarea name="description" class="form-control"></textarea>
                </div>
                <div class="form-group">
                    <label>Gambar Banner</label>
                    <input type="file" name="image" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Urutan Tampil</label>
                    <input type="number" name="order" class="form-control" value="0">
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Simpan Banner</button>
            </div>
        </form>
    </div>
@stop