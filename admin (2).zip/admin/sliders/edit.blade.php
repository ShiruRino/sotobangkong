@extends('adminlte::page')

@section('title', 'Edit Banner Slider')

@section('content_header')
    <h1>Edit Banner: {{ $slider->title_orange }}</h1>
@stop

@section('content')
    <div class="card card-warning">
        <form action="{{ route('sliders.update', $slider->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="title_orange">Judul Oranye (Highlight)</label>
                            <input type="text" name="title_orange" class="form-control @error('title_orange') is-invalid @enderror" id="title_orange" value="{{ old('title_orange', $slider->title_orange) }}" placeholder="Contoh: SOTOBANGKONG">
                            @error('title_orange') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="title_white">Judul Putih</label>
                            <input type="text" name="title_white" class="form-control @error('title_white') is-invalid @enderror" id="title_white" value="{{ old('title_white', $slider->title_white) }}" placeholder="Contoh: JAKARTA">
                            @error('title_white') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Deskripsi Pendek</label>
                    <textarea name="description" class="form-control @error('description') is-invalid @enderror" id="description" rows="3">{{ old('description', $slider->description) }}</textarea>
                    @error('description') <span class="text-danger">{{ $message }}</span> @enderror
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="order">Urutan Tampil</label>
                            <input type="number" name="order" class="form-control @error('order') is-invalid @enderror" id="order" value="{{ old('order', $slider->order) }}">
                            @error('order') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="image">Ganti Gambar Banner (Biarkan kosong jika tidak diubah)</label>
                            @if($slider->image)
                                <div class="mb-2">
                                    <img src="{{ asset('storage/' . $slider->image) }}" alt="Current Slider" class="img-thumbnail" width="200">
                                </div>
                            @endif
                            <div class="custom-file">
                                <input type="file" name="image" class="custom-file-input @error('image') is-invalid @enderror" id="image" accept="image/*">
                                <label class="custom-file-label" for="image">Pilih file gambar baru (Max 2MB)</label>
                            </div>
                            @error('image') <span class="text-danger">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-warning"><i class="fas fa-save"></i> Perbarui Banner</button>
                <a href="{{ route('sliders.index') }}" class="btn btn-default float-right">Batal</a>
            </div>
        </form>
    </div>
@stop

@section('js')
<script>
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });
</script>
@stop