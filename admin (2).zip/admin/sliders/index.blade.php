@extends('adminlte::page')

@section('title', 'Daftar Slider')

@section('content_header')
    <h1>Banner Depan (Slider)</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <a href="{{ route('sliders.create') }}" class="btn btn-primary">Tambah Banner Baru</a>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Urutan</th>
                        <th>Foto</th>
                        <th>Judul</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($sliders as $slider)
                    <tr>
                        <td>{{ $slider->order }}</td>
                        <td><img src="{{ asset('storage/' . $slider->image) }}" width="150"></td>
                        <td>{{ $slider->title_orange }} {{ $slider->title_white }}</td>
                        <td>
                            <a href="{{ route('sliders.edit', $slider->id) }}" class="btn btn-sm btn-warning">Edit</a>
                            <form action="{{ route('sliders.destroy', $slider->id) }}" method="POST" class="d-inline">
                                @csrf @method('DELETE')
                                <button class="btn btn-sm btn-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@stop