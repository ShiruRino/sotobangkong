@extends('adminlte::page')

@section('title', 'Tambah Anggota Tim')

@section('content_header')
    <h1>Tambah Anggota Tim Baru</h1>
@stop

@section('content')
    <div class="card card-primary">
        <form action="{{ route('teams.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="card-body">
                <div class="form-group">
                    <label for="name">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" id="name" placeholder="Contoh: Pak Yanto" value="{{ old('name') }}" required>
                    @error('name') <span class="text-danger">{{ $message }}</span> @enderror
                </div>

                <div class="form-group">
                    <label for="role">Jabatan / Peran <span class="text-danger">*</span></label>
                    <input type="text" name="role" class="form-control @error('role') is-invalid @enderror" id="role" placeholder="Contoh: Kepala Dapur" value="{{ old('role') }}" required>
                    @error('role') <span class="text-danger">{{ $message }}</span> @enderror
                </div>

                <div class="form-group">
                    <label for="image">Foto Anggota <span class="text-danger">*</span></label>
                    <div class="custom-file">
                        <input type="file" name="image" class="custom-file-input @error('image') is-invalid @enderror" id="image" accept="image/*" required>
                        <label class="custom-file-label" for="image">Pilih file gambar (Max 2MB)</label>
                    </div>
                    @error('image') <span class="text-danger">{{ $message }}</span> @enderror
                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Anggota</button>
                <a href="{{ route('teams.index') }}" class="btn btn-default float-right">Batal</a>
            </div>
        </form>
    </div>
@stop

@section('js')
<script>
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });
</script>
@stop