@extends('adminlte::page')

@section('title', 'Edit Anggota Tim')

@section('content_header')
    <h1>Edit Anggota: {{ $team->name }}</h1>
@stop

@section('content')
    <div class="card card-warning">
        <form action="{{ route('teams.update', $team->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="card-body">
                <div class="form-group">
                    <label for="name">Nama Lengkap <span class="text-danger">*</span></label>
                    <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" id="name" value="{{ old('name', $team->name) }}" required>
                    @error('name') <span class="text-danger">{{ $message }}</span> @enderror
                </div>

                <div class="form-group">
                    <label for="role">Jabatan / Peran <span class="text-danger">*</span></label>
                    <input type="text" name="role" class="form-control @error('role') is-invalid @enderror" id="role" value="{{ old('role', $team->role) }}" required>
                    @error('role') <span class="text-danger">{{ $message }}</span> @enderror
                </div>

                <div class="form-group">
                    <label for="image">Foto Anggota (Biarkan kosong jika tidak ingin mengubah)</label>
                    @if($team->image)
                        <div class="mb-2">
                            <img src="{{ asset('storage/' . $team->image) }}" alt="Current Image" class="img-thumbnail" width="150">
                        </div>
                    @endif
                    <div class="custom-file">
                        <input type="file" name="image" class="custom-file-input @error('image') is-invalid @enderror" id="image" accept="image/*">
                        <label class="custom-file-label" for="image">Pilih file gambar baru (Max 2MB)</label>
                    </div>
                    @error('image') <span class="text-danger">{{ $message }}</span> @enderror
                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-warning"><i class="fas fa-save"></i> Update Data</button>
                <a href="{{ route('teams.index') }}" class="btn btn-default float-right">Batal</a>
            </div>
        </form>
    </div>
@stop

@section('js')
<script>
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });
</script>
@stop