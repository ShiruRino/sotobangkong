@extends('adminlte::page')

@section('title', 'Daftar Tim')

@section('content_header')
    <h1>Manajemen Tim Dapur & Staff</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <a href="{{ route('teams.create') }}" class="btn btn-primary">Tambah Staff Baru</a>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Foto</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($teams as $team)
                    <tr>
                        <td><img src="{{ asset('storage/' . $team->image) }}" width="60" class="img-circle"></td>
                        <td>{{ $team->name }}</td>
                        <td>{{ $team->role }}</td>
                        <td>
                            <a href="{{ route('teams.edit', $team->id) }}" class="btn btn-sm btn-warning">Edit</a>
                            <form action="{{ route('teams.destroy', $team->id) }}" method="POST" class="d-inline">
                                @csrf @method('DELETE')
                                <button class="btn btn-sm btn-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@stop