@extends('adminlte::page')

@section('title', 'Manajemen Review')

@section('content_header')
    <h1>Kelola Review Pelanggan</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <a href="{{ route('testimonials.create') }}" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Review</a>
        </div>
        <div class="card-body">
            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th width="10%">Foto</th>
                        <th>Nama & Peran</th>
                        <th>Isi Review</th>
                        <th>Status</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($testimonials as $index => $item)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>
                                @if($item->image)
                                    <img src="{{ asset('storage/' . $item->image) }}" class="img-circle" width="50" height="50" style="object-fit: cover;">
                                @else
                                    <i class="fas fa-user-circle fa-3x text-gray"></i>
                                @endif
                            </td>
                            <td>
                                <strong>{{ $item->name }}</strong><br>
                                <small class="text-muted">{{ $item->role }}</small>
                            </td>
                            <td>"{{ Str::limit($item->content, 100) }}"</td>
                            <td>
                                <span class="badge badge-{{ $item->is_active ? 'success' : 'danger' }}">
                                    {{ $item->is_active ? 'Aktif' : 'Non-Aktif' }}
                                </span>
                            </td>
                            <td>
                                <a href="{{ route('testimonials.edit', $item->id) }}" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                <form action="{{ route('testimonials.destroy', $item->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Hapus review ini?');">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="6" class="text-center">Belum ada review.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@stop